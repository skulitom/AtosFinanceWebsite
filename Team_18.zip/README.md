# AtosFinanceWebsite

Panel headings can be clicked to extract and detract the panel body.

The background image changes every 20 seconds and at the start of page load the transparancy and width of the main page is increased
